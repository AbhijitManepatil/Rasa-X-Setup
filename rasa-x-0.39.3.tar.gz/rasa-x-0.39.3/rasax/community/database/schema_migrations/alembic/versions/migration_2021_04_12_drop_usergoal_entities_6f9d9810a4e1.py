"""Drop UserGoal entities.

Reason:
# With the removal of `UserGoalService`, we need to drop the two tables
# relating to user goals.

Revision ID: 6f9d9810a4e1
Revises: 1080027ae561

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "6f9d9810a4e1"
down_revision = "1080027ae561"
branch_labels = None
depends_on = None


def upgrade():
    """Drop the `UserGoalService`-related tables."""
    op.drop_table("user_goal_intent")
    op.drop_table("user_goal")


def downgrade():
    """Restore the `UserGoalService`-related tables."""
    op.create_table(
        "user_goal",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("name", sa.String(255), nullable=True),
        sa.Column("project_id", sa.String(255), nullable=True),
        sa.ForeignKeyConstraint(["project_id"], ["project.project_id"]),
        sa.PrimaryKeyConstraint("id"),
    )

    op.create_table(
        "user_goal_intent",
        sa.Column("user_goal_id", sa.Integer(), nullable=False),
        sa.Column("intent_name", sa.String(255), nullable=False),
        sa.ForeignKeyConstraint(["user_goal_id"], ["user_goal.id"]),
        sa.PrimaryKeyConstraint("user_goal_id", "intent_name"),
    )
