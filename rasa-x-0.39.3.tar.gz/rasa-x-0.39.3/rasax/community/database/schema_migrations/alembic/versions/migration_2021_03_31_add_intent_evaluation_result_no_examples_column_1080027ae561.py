"""Add number_of_training_examples column to intent_evaluation_result table.

Reason:
To be able to show the number of training examples at the time of
running the cross-validation we also need to store the `support`
value from the cross-validation reports.

Revision ID: 1080027ae561
Revises: d9a565cab06c

"""
import json
from typing import Text

from alembic import op
import sqlalchemy as sa

from rasa.shared.nlu.constants import RESPONSE_IDENTIFIER_DELIMITER

import rasax.community.database.schema_migrations.alembic.utils as migration_utils

TABLE = "intent_evaluation_result"
COLUMN = "number_of_training_examples"
BULK_SIZE = 1000


# revision identifiers, used by Alembic.
revision = "1080027ae561"
down_revision = "d9a565cab06c"
branch_labels = None
depends_on = None


def upgrade():
    """Add `intent_evaluation_result.number_of_training_examples` column and backfill the value."""
    bind = op.get_bind()
    session = sa.orm.Session(bind=bind)

    migration_utils.create_column(
        TABLE,
        sa.Column(COLUMN, sa.Integer(), nullable=False, server_default=sa.text("0")),
    )

    nlu_insight_report_tbl = migration_utils.get_reflected_table(
        "nlu_insight_report", session
    )
    intent_evaluation_result_tbl = migration_utils.get_reflected_table(TABLE, session)

    update_stmt = (
        sa.update(intent_evaluation_result_tbl)
        .where(
            intent_evaluation_result_tbl.c.id
            == sa.bindparam("intent_evaluation_result_id")
        )
        .values({COLUMN: sa.bindparam(COLUMN)})
    )
    update_values = []
    for report in session.query(nlu_insight_report_tbl).yield_per(BULK_SIZE):
        report_payload = _parse_payload(report.evaluation_payload)

        results = session.query(intent_evaluation_result_tbl).filter_by(
            nlu_insight_report_id=report.id
        )
        for result in results:
            evaluation_type = "intent_evaluation"
            if RESPONSE_IDENTIFIER_DELIMITER in result.intent_name:
                evaluation_type = "response_selection_evaluation"

            report_item = (
                report_payload.get(evaluation_type, {})
                .get("report", {})
                .get(result.intent_name, {})
            )
            support = report_item.get("support", 0)
            update_values.append(
                {"intent_evaluation_result_id": result.id, COLUMN: support,}
            )

        if len(update_values) >= BULK_SIZE:
            session.execute(update_stmt, update_values)
            update_values.clear()

    if update_values:
        session.execute(update_stmt, update_values)


def downgrade():
    """Drop the `intent_evaluation_result.number_of_training_examples` column."""
    migration_utils.drop_column(TABLE, COLUMN)


def _parse_payload(payload: Text):
    try:
        return json.loads(payload)
    except (TypeError, json.JSONDecodeError):
        return {}
