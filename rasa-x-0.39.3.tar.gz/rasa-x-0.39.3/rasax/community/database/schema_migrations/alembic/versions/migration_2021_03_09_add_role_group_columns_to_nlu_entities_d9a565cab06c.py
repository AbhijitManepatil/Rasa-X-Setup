"""Add role and group columns to nlu_training_data_entity table.

Reason:
Rasa OSS supports additional `group` and `role` properties for NLU example entities.
This adds two columns to the `nlu_training_data_entity` table to support add support
for them in Rasa X.

Revision ID: d9a565cab06c
Revises: 839cc1322002

"""
import sqlalchemy as sa

import rasax.community.database.schema_migrations.alembic.utils as migration_utils


# revision identifiers, used by Alembic.
revision = "d9a565cab06c"
down_revision = "839cc1322002"
branch_labels = None
depends_on = None

NLU_ENTITY_TABLE = "nlu_training_data_entity"
GROUP_COLUMN = "group"
ROLE_COLUMN = "role"


def upgrade():
    """Add `group` and `role` columns to `nlu_training_data_entity` table."""
    migration_utils.create_column(
        NLU_ENTITY_TABLE, sa.Column(GROUP_COLUMN, sa.String(255), nullable=True)
    )
    migration_utils.create_column(
        NLU_ENTITY_TABLE, sa.Column(ROLE_COLUMN, sa.String(255), nullable=True)
    )


def downgrade():
    """Drop `group` and `role` columns from the `nlu_training_data_entity` table."""
    migration_utils.drop_column(NLU_ENTITY_TABLE, GROUP_COLUMN)
    migration_utils.drop_column(NLU_ENTITY_TABLE, ROLE_COLUMN)
