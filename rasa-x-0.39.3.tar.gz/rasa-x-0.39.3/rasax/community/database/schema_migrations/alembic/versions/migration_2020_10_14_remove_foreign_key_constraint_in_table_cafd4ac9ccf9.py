"""Remove `created_by` foreign key constraint in `conversations` table.

Reason:
A user may be deleted while the interactive learning conversations created by that user
can remain.

Revision 7b2497cd88dc introduced a new column `created_by` to the `conversations`
table. This column contains information on the creator of interactive learning
conversations, and contained a foreign key constraint to the `username`
column of the `rasa_x_user`.

This migration removes the foreign key constraint to the `username` column, so that
conversations can remain in the database even if the user mentioned in the
`created_by` column has been deleted.

Revision ID: cafd4ac9ccf9
Revises: 6af361a57ca6

"""
from alembic import op

import rasax.community.database.schema_migrations.alembic.utils as migration_utils

# revision identifiers, used by Alembic.
revision = "cafd4ac9ccf9"
down_revision = "6af361a57ca6"
branch_labels = None
depends_on = None

TABLE_NAME = "conversation"
CREATED_BY_COLUMN = "created_by"
FOREIGN_KEY_NAME = "fk_conversation_username"


def upgrade():
    if migration_utils.get_column(TABLE_NAME, CREATED_BY_COLUMN) is not None:
        with op.batch_alter_table(TABLE_NAME) as batch_op:  # type: op.BatchOperations
            batch_op.drop_constraint(FOREIGN_KEY_NAME)


def downgrade():
    if migration_utils.get_column(TABLE_NAME, CREATED_BY_COLUMN) is not None:
        with op.batch_alter_table(TABLE_NAME) as batch_op:
            batch_op.create_foreign_key(
                FOREIGN_KEY_NAME, "rasa_x_user", [CREATED_BY_COLUMN], ["username"]
            )
