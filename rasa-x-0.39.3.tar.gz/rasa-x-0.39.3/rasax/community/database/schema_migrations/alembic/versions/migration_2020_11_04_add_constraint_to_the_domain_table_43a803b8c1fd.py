"""Add constraint to the Domain table.

Reason:
In order to support multiple domains within one project (post Rasa Open Source 2.0),
we need to make sure that pair [project_id, path] in the `Domain` table is unique.
Also, we make `path` field non-nullable, making sure that existing empty records
will get a `domain_migrated_during_{revision}_N.yml` name assigned.
Also we rename column `path` -> `filename`, that is more consistent with the rest of the
DB schema, and better reflects the purpose of the column.

Revision ID: 43a803b8c1fd
Revises: d9156a63aa00

"""
from pathlib import Path

import rasax.community.database.schema_migrations.alembic.utils as migration_utils
import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision = "43a803b8c1fd"
down_revision = "052172fdb4b3"
branch_labels = None
depends_on = None

TABLE_NAME = "domain"
COLUMN_PROJECT_ID = "project_id"
COLUMN_PATH = "path"
COLUMN_FILENAME = "filename"
COLUMN_TO_DELETE = "to_delete"
# Oracle limitation for the name length
CONSTRAINT_NAME = "domain_proj_id_filename_cnst"


def _ensure_domains_have_unique_filename():
    bind = op.get_bind()
    session = sa.orm.Session(bind=bind)

    domain_table = migration_utils.get_reflected_table(TABLE_NAME, session)

    existing_names = set()
    for next_id, domain in enumerate(
        session.query(domain_table).order_by(domain_table.c.id.desc()).all(), 1
    ):
        if not domain.filename:
            domain.filename = "."

        if domain.filename not in existing_names and domain.filename != ".":
            existing_names.add(domain.filename)
            continue

        domain_file_parent = Path(domain.filename).parent
        domain_name = str(
            domain_file_parent / f"domain_migrated_during_{revision}_{next_id}.yml"
        )

        query = (
            sa.update(domain_table)
            .where(domain_table.c.id == domain.id)
            .values(filename=str(domain_name),)
        )
        session.execute(query)

    session.commit()


def _add_domain_constraint():
    modifications = [
        migration_utils.ColumnTransformation(
            COLUMN_FILENAME,
            [sa.String(255)],
            {"server_default": "domain.yml", "nullable": False},
        )
    ]
    migration_utils.modify_columns(TABLE_NAME, modifications)

    with op.batch_alter_table(TABLE_NAME) as batch_op:
        batch_op.create_unique_constraint(
            CONSTRAINT_NAME, [COLUMN_PROJECT_ID, COLUMN_FILENAME, COLUMN_TO_DELETE]
        )


def _rename_path_to_filename():
    migration_utils.rename_column(TABLE_NAME, COLUMN_PATH, COLUMN_FILENAME)


def _rename_filename_to_path():
    migration_utils.rename_column(TABLE_NAME, COLUMN_FILENAME, COLUMN_PATH)


def _add_to_delete_column():
    migration_utils.create_column(
        TABLE_NAME,
        sa.Column(
            COLUMN_TO_DELETE,
            sa.Boolean,
            nullable=False,
            default=False,
            server_default="0",
        ),
    )


def _drop_to_delete_column():
    migration_utils.drop_column(TABLE_NAME, COLUMN_TO_DELETE)


def upgrade():
    """Perform upgrade of the DB schema."""
    _rename_path_to_filename()
    _ensure_domains_have_unique_filename()
    _add_to_delete_column()
    _add_domain_constraint()


def downgrade():
    """Perform downgrade of the DB schema."""
    modifications = [
        migration_utils.ColumnTransformation(
            COLUMN_FILENAME, [sa.String(255)], {"nullable": True}
        )
    ]
    migration_utils.modify_columns(TABLE_NAME, modifications)

    with op.batch_alter_table(TABLE_NAME) as batch_op:
        batch_op.drop_constraint(CONSTRAINT_NAME)

    _rename_filename_to_path()
    _drop_to_delete_column()
