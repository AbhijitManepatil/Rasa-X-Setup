"""Merge branched out revision with main migration path.

Reason:
A performance fix (https://github.com/RasaHQ/rasa-x/pull/3803) for 0.31.x and 0.32.x
required a migration. This migration represents a separate branch in our graph of
migrations.

This means users installing 0.35.x can have different migration paths:
- Coming from a previous version which didn't have a revision `17e6230c5f40`
- Coming from one of the fixed 0.31.x / 0.32.x versions which have a revision
  `17e6230c5f40`

We added a migration script with revision `17e6230c5f40` to 0.35.0
which will only be executed for users coming from a previous version which didn't have
a revision `17e6230c5f40` (e.g. 0.34).
This means that both user groups will now have two migration heads which will need to
be merged.

This migration merges both heads and brings all users back on the same migration path.

Revision ID: e4ed14831f48
Revises: (17e6230c5f40, 43a803b8c1fd)
"""

revision = "e4ed14831f48"
# 17e6230c5f40 = migration which caused the branching
# 43a803b8c1fd = Our main migration branch
down_revision = ("17e6230c5f40", "43a803b8c1fd")
branch_labels = None
depends_on = None


def upgrade():
    """Runs migration to upgrade to this revision."""
    pass


def downgrade():
    """Runs migration to downgrade from this revision."""
    pass
