"""Add new domain-related columns

Reason:
Add the `data` column to the domain actions table so that we can store
Form-specific data for the new Rasa Open Source 2.0 domain format.

Also, add three columns to the domain slots table: `min_value` and `max_value`,
which were not present before, and the new `influence_conversation` boolean
property introduced in 2.0.

Revision ID: 9b0753451554
Revises: cafd4ac9ccf9

"""
from alembic import op
import sqlalchemy as sa
import rasax.community.database.schema_migrations.alembic.utils as migration_utils


# revision identifiers, used by Alembic.
revision = "9b0753451554"
down_revision = "cafd4ac9ccf9"
branch_labels = None
depends_on = None


CHANGES = [
    ("domain_action", sa.Column("data", sa.Text())),
    ("domain_slot", sa.Column("min_value", sa.Float())),
    ("domain_slot", sa.Column("max_value", sa.Float())),
    ("domain_slot", sa.Column("influence_conversation", sa.Boolean())),
]


def upgrade():
    for table_name, column in CHANGES:
        if not migration_utils.get_column(table_name, column.name):
            migration_utils.create_column(table_name, column)


def downgrade():
    for table_name, column in CHANGES:
        if migration_utils.get_column(table_name, column.name):
            migration_utils.drop_column(table_name, column.name)
