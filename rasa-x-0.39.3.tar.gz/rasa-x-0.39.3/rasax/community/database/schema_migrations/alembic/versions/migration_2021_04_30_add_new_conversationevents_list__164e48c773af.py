"""Add new conversationEvents.list permission.

Reason:
We need a new permission to decide whether a user can access events from all conversations.
Given that in the frontend roles only add permissions by group, we need to add this
new permission to all roles which already have other `conversations.view` permissions
added.

Revision ID: 164e48c773af
Revises: 6f9d9810a4e1

"""
from alembic import op
import sqlalchemy as sa
import rasax.community.database.schema_migrations.alembic.utils as migration_utils


# revision identifiers, used by Alembic.
revision = "164e48c773af"
down_revision = "6f9d9810a4e1"
branch_labels = None
depends_on = None


NEW_PERMISSION = "conversations.view.conversationEvents.list"
TABLE_PERMISSION = "permission"
LOOKUP_PERMISSIONS = [
    "conversations.view.conversationActions.list",
    "conversations.view.conversationEntities.list",
    "conversations.view.conversationIntents.list",
    "conversations.view.conversationPolicies.list",
    "conversations.view.conversationDataTag.list",
    "conversations.view.conversationSlotNames.list",
    "conversations.view.conversationSlotValues.list",
    "conversations.view.conversationInputChannels.list",
]


def upgrade():
    """Check for conversations.view.{} permissions and add conversationEvents.list permission."""
    bind = op.get_bind()
    session = sa.orm.Session(bind=bind)

    permission_tbl = migration_utils.get_reflected_table(TABLE_PERMISSION, session)
    query = (
        session.query(permission_tbl.c.role_id, permission_tbl.c.project)
        .filter(permission_tbl.c.permission.in_(LOOKUP_PERMISSIONS))
        .group_by(permission_tbl.c.role_id, permission_tbl.c.project)
    )

    for row in query:
        role_id = row[0]
        project = row[1]
        insert = sa.insert(permission_tbl).values(
            project=project, role_id=role_id, permission=NEW_PERMISSION
        )
        session.execute(insert)


def downgrade():
    """Remove conversationEvents.list from any role."""
    bind = op.get_bind()
    session = sa.orm.Session(bind=bind)

    permission_tbl = migration_utils.get_reflected_table(TABLE_PERMISSION, session)
    delete = sa.delete(permission_tbl).where(
        permission_tbl.c.permission == NEW_PERMISSION
    )
    session.execute(delete)
