import argparse
import asyncio
import contextlib
import json
import logging
import math
import os
import sys
import textwrap
from abc import ABC
from collections import defaultdict, OrderedDict, Counter
from pathlib import Path
from typing import (
    Dict,
    Text,
    Union,
    Any,
    Optional,
    List,
    NamedTuple,
    Callable,
    Type,
    Tuple,
)

import rasa.shared.utils.io
import rasa.shared.utils.cli
import rasa.shared.utils.common
import rasax.community.config
import rasax.community.database.utils
import rasax.community.utils.io
import sqlalchemy
from rasa.shared.constants import DEFAULT_NLU_FALLBACK_INTENT_NAME
from rasa.shared.exceptions import YamlSyntaxException
from rasa.shared.importers.rasa import RasaFileImporter
from rasa.shared.nlu.constants import INTENT, INTENT_RESPONSE_KEY
from rasa.shared.nlu.training_data.training_data import TrainingData
from rasax.community.constants import RASA_PRODUCTION_ENVIRONMENT, ENV_DB_URL
from rasax.community.database import MessageLog, IntentInsight
from rasax.community.services.data_service import DataService
from rasax.community.services.model_service import ModelService
from sqlalchemy.orm import Session
from terminaltables import AsciiTable

logger = logging.getLogger(__name__)


INTENT_REPORT_SUMMARY_KEYS = {"micro avg", "macro avg", "weighted avg", "accuracy"}

INTENT_LABEL = "intent"
INTENT_PREDICTION = "intent_prediction"

RESPONSE_SELECTOR_LABEL = "intent_response_key_target"
RESPONSE_SELECTOR_PREDICTION = "intent_response_key_prediction"


class NLUEvaluation(NamedTuple):
    """Contains evaluation results for either (retrieval) intents or entities."""

    report: Dict[Text, Any]
    errors: List[Dict[Text, Any]]

    @classmethod
    def empty(cls) -> "NLUEvaluation":
        """Returns an empty NLUEvaluation instance."""
        return NLUEvaluation({}, [])

    @classmethod
    def from_rasa_format(cls, evaluation: Dict[Text, Any]) -> "NLUEvaluation":
        """Converts from Rasa Open Source evaluation dictionary.

        Args:
            evaluation: (Retrieval) intent evaluation as returned by the Rasa Open
                Source endpoint.

        Returns:
            Converted evaluation.
        """
        return NLUEvaluation(evaluation.get("report", {}), evaluation.get("errors", []))


class NLUInsightCalculator(ABC):
    """Interface for classes which calculate insights for the NLU model."""

    def lint_intents(
        self, evaluation: NLUEvaluation, database_session: Optional[Session] = None,
    ) -> Dict[Text, "Insight"]:
        """Calculate insights for intents.

        Args:
            training_data: The current NLU training data.
            evaluation: Evaluation results for the model (`rasa test nlu`) or the given
                training data (`rasa test nlu --cross-validation`).
            database_session: Rasa X database session. Can e.g. be used to calculate
                insights based on recent user messages.

        Returns:
            Mapping of problematic intents and the related insight describing the issue.
        """
        return {}

    def lint_retrieval_intents(
        self, evaluation: NLUEvaluation, database_session: Optional[Session] = None,
    ) -> Dict[Text, "Insight"]:
        """Calculate insights for retrieval intents.

        Args:
            evaluation: Evaluation results for the model (`rasa test nlu`) or the given
                training data (`rasa test nlu --cross-validation`).
            database_session: Rasa X database session. Can e.g. be used to calculate
                insights based on recent user messages.

        Returns:
            Mapping of problematic intents and the related insight describing the issue.
        """
        return {}

    def __repr__(self) -> Text:
        """Returns a full representation of the object for debugging."""
        return f"{self.__class__.__name__}: {self.__dict__}"


class Insight:
    """Describes a potential problem within the current training data."""

    def __init__(
        self,
        source: Text,
        details: Optional[Dict[Text, Any]] = None,
        description: Optional[Text] = None,
    ) -> None:
        """Creates insight.

        Args:
            source: Linter which gave the suggestion.
            details: Additional details which describe the issue.
            description: Human readable explanation of the error.
        """
        self.source = source
        self.details = details or {}
        self.description = description

    def __eq__(self, other: Any) -> bool:
        """Checks if other object equals this insight."""
        if not isinstance(other, Insight):
            return NotImplemented

        return self.source == other.source and self.details == other.details

    def __str__(self) -> Text:
        """Returns string representation of insight for end users."""
        return f"{self.source}: {self.description}"

    def __repr__(self) -> Text:
        """Returns string representation of insight for debugging."""
        return f"{self.__class__.__name__}: {json.dumps(self.details)}"

    def as_orm(self) -> IntentInsight:
        """Converts the `Insight` object used inside calculator to database object."""
        return IntentInsight(source=self.source, details=json.dumps(self.details))


class MinimumExampleInsightCalculator(NLUInsightCalculator):
    """Checks whether all intents have enough training examples."""

    def __init__(self, required_number_of_examples_per_intent: int = 20) -> None:
        """Creates object.

        Args:
            required_number_of_examples_per_intent: Each intent has to have all least
                this number of training examples. Otherwise a suggestion is created
                for this intent.
        """
        super().__init__()
        self.required_number_of_examples_per_intent = (
            required_number_of_examples_per_intent
        )

    def lint_intents(
        self, evaluation: NLUEvaluation, _: Optional[Session] = None,
    ) -> Dict[Text, "Insight"]:
        """See parent class docstring."""
        # Exclude retrieval intents as we lint them separately
        intents = {}
        for intent in evaluation.report.keys() - INTENT_REPORT_SUMMARY_KEYS:
            intents[intent] = evaluation.report[intent].get("support", 0)

        return self._lint(intents)

    def lint_retrieval_intents(
        self, evaluation: NLUEvaluation, _: Optional[Session] = None,
    ) -> Dict[Text, "Insight"]:
        """See parent class docstring."""
        retrieval_intents = {}
        for retrieval_intent in evaluation.report.keys() - INTENT_REPORT_SUMMARY_KEYS:
            retrieval_intents[retrieval_intent] = evaluation.report[
                retrieval_intent
            ].get("support", 0)
        return self._lint(retrieval_intents)

    def _lint(self, counts: Dict[Text, int]) -> Dict[Text, "Insight"]:
        return {
            intent_name: Insight(
                source=self.__class__.__name__,
                details={"number_of_training_examples": number_of_examples,},
                description=f"The intent '{intent_name}' has only {number_of_examples} "
                f"training examples. This is less than the required minimum of "
                f"{self.required_number_of_examples_per_intent}. "
                f"Annotate more examples for this intent so that the "
                "classifier can learn examples for this intent better. "
                "You can e.g. use the NLU inbox to create more training "
                "data for this intent.",
            )
            for intent_name, number_of_examples in counts.items()
            if number_of_examples < self.required_number_of_examples_per_intent
        }


class ConfusionInsightCalculator(NLUInsightCalculator):
    """Checks if an intent is confused often.

    This e.g. happens when the training data of intents is too similar.
    """

    def __init__(
        self, top_x_percent_threshold: float = 1.0, recall_threshold: float = 0.85
    ) -> None:
        """Creates object.

        Args:
            top_x_percent_threshold: Order results by recall and return only the
                top `top_x_percent_threshold` percent.
            recall_threshold: An insight is only created if the recall for the intent
                is lower than this threshold. This avoids raising errors for intents
                which are confused because of a high bias (there is a separate
                insights calculator for that).
        """
        super().__init__()
        self.top_x_percent_threshold = top_x_percent_threshold
        self.recall_threshold = recall_threshold

    def lint_intents(
        self, evaluation: NLUEvaluation, __: Optional[Session] = None,
    ) -> Dict[Text, "Insight"]:
        """See parent class docstring."""
        return self._lint(evaluation)

    def lint_retrieval_intents(
        self, evaluation: NLUEvaluation, __: Optional[Session] = None,
    ) -> Dict[Text, "Insight"]:
        """See parent class docstring."""
        return self._lint(evaluation)

    def _lint(self, evaluation: NLUEvaluation) -> Dict[Text, "Insight"]:
        report = evaluation.report
        intents_with_confusions = {
            intent_name: (
                report.get("recall", 1),
                OrderedDict(
                    sorted(
                        report.get("confused_with", {}).items(),
                        key=lambda item: item[1],
                        reverse=True,
                    )
                ),
            )
            for intent_name, report in report.items()
            if intent_name not in INTENT_REPORT_SUMMARY_KEYS
            and report.get("recall", 1) <= self.recall_threshold
            and len(report.get("confused_with", {})) > 0
        }

        number_of_confused_items = len(intents_with_confusions.keys())
        intents_to_report = math.ceil(
            self.top_x_percent_threshold * number_of_confused_items
        )

        # Sort by recall as it takes the number of confusions in account but does not
        # use the absolute number of wrong predictions.
        sorted_by_recall = sorted(
            intents_with_confusions.items(), key=lambda item: item[1][0], reverse=True,
        )
        return {
            intent_name: Insight(
                source=self.__class__.__name__,
                details={"recall": recall, "confusions": confusions},
                description=f"Intent '{intent_name}' was confused multiple times with"
                f" a recall of {recall:.3f}. "
                f"The confused intents were: {', '.join(list(confusions.keys())[:3])}"
                f"You should examine if the examples for intent "
                f"'{intent_name}' are similar to training examples for the "
                f"confused intents. If yes, you can either merge these "
                f"intents into one intent or break these intents further "
                f"down into smaller intents to make them more distinct.",
            )
            for intent_name, (recall, confusions) in sorted_by_recall[
                :intents_to_report
            ]
        }


class ClassBiasInsightCalculator(NLUInsightCalculator):
    """Checks for intents which are predominantly selected.

    Happens when there is a bias for this intent (e.g. because it has much more
    training data than other intents).
    """

    def __init__(
        self, maximal_precision: float = 0.4, minimum_recall: float = 0.8
    ) -> None:
        """Creates object.

        Args:
            maximal_precision: Only create insight if intent has precision lower than
                the given threshold. A low precision and high recall indicate that
                the intent is predicted often although it's actually a different one.
            minimum_recall: Only create insight if recall for intent is greater
                than recall threshold. If `recall` is high, it's an indicator that
                the intent is selected too often.
        """
        super().__init__()
        self.maximal_precision = maximal_precision
        self.minimum_recall = minimum_recall

    def lint_intents(
        self, evaluation: NLUEvaluation, _: Optional[Session] = None,
    ) -> Dict[Text, "Insight"]:
        """See parent class docstring."""
        return self._lint(evaluation)

    def lint_retrieval_intents(
        self, evaluation: NLUEvaluation, database_session: Optional[Session] = None,
    ) -> Dict[Text, "Insight"]:
        """See parent class docstring."""
        return self._lint(evaluation)

    def _lint(self, evaluation: NLUEvaluation) -> Dict[Text, "Insight"]:
        report = evaluation.report
        return {
            intent_name: Insight(
                source=self.__class__.__name__,
                details={
                    "precision": report.get("precision", 1),
                    "recall": report.get("recall", 0),
                },
                description=f"Intent '{intent_name}' was classified with an average "
                f"precision of {report.get('precision')}, but only with a "
                f"recall of {report.get('recall')}."
                "There is a possibility that this is caused by too many "
                f"examples for intent '{intent_name}'. Big differences in "
                f"the number of examples per intent can lead to a biased "
                f"model. We suggest to reduce the number of training "
                f"examples for intent '{intent_name}'.",
            )
            for intent_name, report in report.items()
            if intent_name not in INTENT_REPORT_SUMMARY_KEYS
            and report.get("precision", 1) < self.maximal_precision
            and report.get("recall", 0) > self.minimum_recall
        }


class WrongAnnotationInsightCalculator(NLUInsightCalculator):
    """Checks for intents which are diluted by wrongly annotated training data."""

    def __init__(
        self, confidence_threshold: float = 0.9, top_x_percent_threshold: float = 0.1
    ) -> None:
        """Creates object.

        Args:
            confidence_threshold: Only create insights if an intent is wrongly predicted
                with a confidence greater than threshold. If confidence is low, the
                model is probably unsure in general. If the confidence is high, it means
                that the model learned this (wrong) behavior somewhere.
            top_x_percent_threshold: Order insights by number of wrong predictions
                and return only top `top_x_percent_threshold` percent of wrongly
                predicted intents.
        """
        super().__init__()
        self.confidence_threshold = confidence_threshold
        self.top_x_percent_threshold = top_x_percent_threshold

    def lint_intents(
        self, evaluation: NLUEvaluation, _: Optional[Session] = None,
    ) -> Dict[Text, "Insight"]:
        """See parent class docstring."""
        return self._lint(
            evaluation, label_key=INTENT_LABEL, prediction_key=INTENT_PREDICTION
        )

    def lint_retrieval_intents(
        self, evaluation: NLUEvaluation, database_session: Optional[Session] = None,
    ) -> Dict[Text, "Insight"]:
        """See parent class docstring."""
        return self._lint(
            evaluation,
            label_key=RESPONSE_SELECTOR_LABEL,
            prediction_key=RESPONSE_SELECTOR_PREDICTION,
        )

    def _lint(
        self, evaluation: NLUEvaluation, label_key: Text, prediction_key: Text
    ) -> Dict[Text, "Insight"]:
        errors = evaluation.errors
        wrong_classifications_with_high_confidence = [
            intent_error
            for intent_error in errors
            # Wrong classification with high confidence
            if intent_error.get(prediction_key, {}).get("confidence", 0)
            > self.confidence_threshold
            # Fallback intent means it was a wrong classification with low confidence
            and intent_error.get(prediction_key, {}).get("name")
            != DEFAULT_NLU_FALLBACK_INTENT_NAME
        ]

        wrong_classifications_per_intent = defaultdict(int)
        for intent_error in wrong_classifications_with_high_confidence:
            intent_name = intent_error[label_key]
            wrong_classifications_per_intent[intent_name] += 1

        number_of_wrong_intents = len(wrong_classifications_per_intent.keys())
        intents_to_report = math.ceil(
            self.top_x_percent_threshold * number_of_wrong_intents
        )

        sorted_by_wrong_classifications = sorted(
            wrong_classifications_per_intent.items(),
            key=lambda item: item[1],
            reverse=True,
        )

        return {
            intent_name: Insight(
                source=self.__class__.__name__,
                details={"number_of_wrong_classifications": wrong_classifications},
                description=f"Intent '{intent_name}' was classified wrong for "
                f"{wrong_classifications} times with a confidence greater than "
                f"{self.confidence_threshold}."
                f"There is a possibility that some examples for intent "
                f"'{intent_name}' are wrongly annotated with a different "
                f"intent. Please verify if the annotations for this intent "
                f"are correct.",
            )
            for intent_name, wrong_classifications in sorted_by_wrong_classifications[
                :intents_to_report
            ]
            if wrong_classifications > 0
        }


class NLUInboxConfidenceInsightCalculator(NLUInsightCalculator):
    """Searches the NLU Inbox for user message predictions with low confidence."""

    def __init__(
        self,
        lower_confidence_threshold: float = 0.3,
        upper_confidence_threshold: float = 0.8,
        only_classifications_by_active_model: bool = True,
        minimal_timestamp: float = 0,
        top_x_percent_threshold: float = 0.1,
    ) -> None:
        """Creates object.

        Args:
            lower_confidence_threshold: Only look for messages with confidences greater
                equals than the threshold. Avoids creating an insight for an intent
                if the model had in general no clue about the message.
            upper_confidence_threshold: Only look for messages with confidence scores
                smaller or equal than threshold. No need to create an insight for
                messages which are classified with high confidence (could either be
                right prediction or bias for this intent).
            only_classifications_by_active_model: Only look within predictions which
                were performed by the currently active model.
            minimal_timestamp: Only look within message predictions which were
                done after a certain time.
            top_x_percent_threshold: Order intents by number of low confidence
                predictions and only return errors for top `top_x_percent_threshold`
                percent of items.
        """
        self.lower_confidence_threshold = lower_confidence_threshold
        self.upper_confidence_threshold = upper_confidence_threshold
        self.only_classifications_by_active_model = only_classifications_by_active_model
        self.minimal_timestamp = minimal_timestamp
        self.top_x_percent_threshold = top_x_percent_threshold

    def lint_intents(
        self, _: NLUEvaluation, database_session: Optional[Session] = None,
    ) -> Dict[Text, "Insight"]:
        """See parent class docstring."""
        if not database_session:
            return {}

        model_query = True
        if self.only_classifications_by_active_model:
            model_service = ModelService("", database_session)
            active_model = model_service.model_for_tag(
                rasax.community.config.project_name, RASA_PRODUCTION_ENVIRONMENT
            )

            if active_model:
                model_query = MessageLog.model == active_model["model"]

        query = database_session.query(
            MessageLog.intent, MessageLog.intent_ranking
        ).filter(
            MessageLog.in_training_data == sqlalchemy.false(),
            MessageLog.archived == sqlalchemy.false(),
            MessageLog.time >= self.minimal_timestamp,
            MessageLog.confidence >= self.lower_confidence_threshold,
            MessageLog.confidence <= self.upper_confidence_threshold,
            model_query,
        )

        low_confidence_predictions = query.all()

        low_confidence_classifications_per_intent = defaultdict(int)
        for prediction in low_confidence_predictions:
            intent = prediction.intent
            if intent == DEFAULT_NLU_FALLBACK_INTENT_NAME:
                intent_ranking = json.loads(prediction.intent_ranking)
                if len(intent_ranking) > 1:
                    # intent_ranking[0] is `nlu_fallback`, [1] is the actual prediction
                    intent = intent_ranking[1]["name"]

            low_confidence_classifications_per_intent[intent] += 1

        sorted_by_low_confidence_predictions = sorted(
            low_confidence_classifications_per_intent.items(),
            key=lambda item: item[1],
            reverse=True,
        )
        intents_to_report = math.ceil(
            self.top_x_percent_threshold
            * len(low_confidence_classifications_per_intent.keys())
        )

        return {
            intent_name: Insight(
                source=self.__class__.__name__,
                details={
                    "number_of_low_confidence_predictions": low_confidence_predictions
                },
                description=f"Intent '{intent_name}' was repeatedly predicted with low "
                f"confidence values."
                f"Annotate more examples for this intent so that the "
                f"classifier can learn examples for this intent better. "
                f"You can e.g. use the NLU inbox to create more trainin g"
                f"data for this intent.",
            )
            for intent_name, low_confidence_predictions in sorted_by_low_confidence_predictions[
                :intents_to_report
            ]
            if low_confidence_predictions > 0
        }


def calculate_insights(
    database_session: Session,
    rasa_evaluation_results: Dict[Text, Any],
    calculator_config: Optional[Dict[Text, Any]] = None,
) -> Tuple[Dict[Text, List[IntentInsight]], Dict[Text, List[IntentInsight]]]:
    """Calculate the intent insights for Rasa X.

    Args:
        database_session: The current database session.
        rasa_evaluation_results: A cross-validation result of the current training data.
        calculator_config: Current configuration of the insight calculators or `None`
            if default config should be used.

    Returns:
        Intent names and potential insights for each of them.
    """
    intent_evaluation = NLUEvaluation.from_rasa_format(
        rasa_evaluation_results.get("intent_evaluation", {})
    )
    retrieval_intent_evaluation = NLUEvaluation.from_rasa_format(
        rasa_evaluation_results.get("response_selection_evaluation", {})
    )

    intent_insights, retrieval_intent_insights = collect_insights(
        intent_evaluation,
        retrieval_intent_evaluation,
        database_session,
        calculator_config,
    )

    return (
        _insights_to_orm(intent_insights),
        _insights_to_orm(retrieval_intent_insights),
    )


def collect_insights(
    intent_evaluation: NLUEvaluation,
    retrieval_intent_evaluation: NLUEvaluation,
    database_session: Optional[Session] = None,
    calculator_config: Optional[Dict[Text, Any]] = None,
) -> Tuple[Dict[Text, List["Insight"]], Dict[Text, List["Insight"]]]:
    """Collects insights for the intents.

    Args:
        intent_evaluation: Test report and errors during for the intents.
        retrieval_intent_evaluation: Test report and errors for the retrieval intents.
        database_session: Rasa X database session to include recent model predictions
            in the insight calculation.
        calculator_config: Linters to use for insight calculation.
            Uses defaults if `None`.

    Returns:
        A mapping of intents to insights and a mapping of retrieval intents to insights.
    """
    calculators = insight_calculators_from_config(calculator_config)

    stringified_config = "\n".join([f"- {calculator}" for calculator in calculators])
    logger.debug(f"The following linters will be used:\n{stringified_config}")

    intent_insights = defaultdict(list)
    retrieval_intent_insights = defaultdict(list)

    for insight_calculator in calculators:
        try:
            new_intent_suggestions = insight_calculator.lint_intents(
                intent_evaluation, database_session
            )
            _add_suggestions(intent_insights, new_intent_suggestions)

            new_retrieval_intent_suggestions = insight_calculator.lint_retrieval_intents(
                retrieval_intent_evaluation, database_session
            )
            _add_suggestions(
                retrieval_intent_insights, new_retrieval_intent_suggestions
            )
        except Exception as e:
            logger.error(
                f"Insight calculation by "
                f"'{insight_calculator.__class__.__name__}' failed. Skipping "
                f"insight collection for this insight calculator. "
                f"Details:\n{e}"
            )

    return intent_insights, retrieval_intent_insights


def _add_suggestions(
    all_suggestions: Dict[Text, List[Insight]], new_insights: Dict[Text, Insight]
) -> None:
    for intent_name, suggestion in new_insights.items():
        all_suggestions[intent_name].append(suggestion)


def _default_insight_calculators() -> Dict[Text, Callable[..., NLUInsightCalculator]]:
    return {
        calculator.__name__: calculator
        for calculator in [
            MinimumExampleInsightCalculator,
            ConfusionInsightCalculator,
            ClassBiasInsightCalculator,
            WrongAnnotationInsightCalculator,
            NLUInboxConfidenceInsightCalculator,
        ]
    }


def serializable_default_config() -> Dict[Text, Dict[Text, Any]]:
    """Returns the default config in a serializable format.

    Returns:
        A mapping of calculator names and their configuration parameters. An empty
        configuration means that the default parameters of the classes will be used.
    """
    return {calculator_name: {} for calculator_name in _default_insight_calculators()}


def insight_calculators_from_config(
    calculator_config: Optional[Dict[Text, Any]] = None
) -> List[NLUInsightCalculator]:
    """Loads the insights calculators from a configuration.

    Args:
        calculator_config: Mapping of names to insight calculators.
            If name is not found, interprets name as module string and tries to load
            class from that.

    Returns:
         Instantiated `InsightCalculator`s. If no config was passed, default insight
            calculators are returned.
    """
    if calculator_config is None:
        calculator_config = serializable_default_config()

    calculators = []
    default_calculators = _default_insight_calculators()
    for calculator_name, config in calculator_config.items():
        calculator: Optional[
            Callable[..., NLUInsightCalculator]
        ] = default_calculators.get(calculator_name)

        if calculator:
            calculators.append(calculator(**config))
            continue

        custom_calculator = rasa.shared.utils.common.class_from_module_path(
            calculator_name
        )
        logger.debug(f"Loaded {calculator_name} from module.")
        calculators.append(custom_calculator(**config))

    return calculators


def validate_calculator_config(calculator_config: Optional[Dict[Text, Any]]) -> None:
    """Validates calculator config.

    Args:
        calculator_config: The configuration for the insight calculators.

    Raises:
        ValueError: If config is invalid.
    """
    try:
        insight_calculators_from_config(calculator_config)
    except Exception as e:
        logger.error(f"Invalid intent insight calculator config:\n{e}")
        raise ValueError(f"Invalid linter config. Details:\n{e}") from e


def _insights_to_orm(
    insights: Dict[Text, List["Insight"]]
) -> Dict[Text, List[IntentInsight]]:
    return {
        intent_name: [insight.as_orm() for insight in insights_for_intent]
        for intent_name, insights_for_intent in insights.items()
    }


def calculate_insights_for_cli(cli_args: argparse.Namespace) -> None:
    """Calculates and prints NLU insights based on CLI arguments.

    Args:
        cli_args: The parsed CLI arguments.
    """
    logging.basicConfig(level=logging.INFO)
    if cli_args.debug:
        logger.setLevel(logging.DEBUG)

    context_manager = contextlib.nullcontext(None)
    if cli_args.database_url:
        context_manager = rasax.community.database.utils.session_scope(
            db_url=cli_args.database_url
        )

    with context_manager as session:
        rasa.shared.utils.cli.print_info("Analyzing your NLU data ... 🔎")
        loop = asyncio.get_event_loop()
        warnings = loop.run_until_complete(
            _get_insights_for_cli(
                cli_args.linter_config, cli_args.test_results, session,
            )
        )

    if warnings:
        rasa.shared.utils.cli.print_info(
            "Suggestions to improve your training data were found 🚨"
        )
        print_insights(warnings)
        sys.exit(1)

    rasa.shared.utils.cli.print_success("No issues found 🎉")


async def _get_insights_for_cli(
    linter_config_file: Optional[Text] = None,
    path_to_evaluation_directory: Union[Path, Text, None] = None,
    database_session: Optional[Session] = None,
) -> Dict[Text, List["Insight"]]:
    intent_evaluation = _test_results(path_to_evaluation_directory)
    calculator_config = _config_from_file(linter_config_file)

    intent_insights, retrieval_intent_insights = collect_insights(
        intent_evaluation, NLUEvaluation.empty(), database_session, calculator_config,
    )

    intent_insights.update(retrieval_intent_insights)

    return intent_insights


async def _training_data(
    nlu_data_path: Union[Path, Text, None], database_session: Session = None
) -> TrainingData:
    has_local_training_data = bool(nlu_data_path and Path(nlu_data_path).exists())

    if database_session and not has_local_training_data:
        logger.debug("Obtaining training data from database.")
        return _training_data_from_database(database_session)

    if has_local_training_data:
        logger.debug("Using training data from files.")
        importer = RasaFileImporter(training_data_paths=[nlu_data_path])
        return await importer.get_nlu_data()

    rasa.shared.utils.cli.print_warning(
        "NLU training data not found. Analyzes based on the training data will "
        "be skipped. Consider providing your NLU training data for more "
        "meaningful results using the '--training-data' flag."
    )

    return TrainingData()


def _training_data_from_database(database_session: Session) -> TrainingData:
    nlu_service = DataService(database_session)
    return nlu_service.get_nlu_training_data_object(rasax.community.config.project_name)


def _test_results(path_to_evaluation_result: Union[Path, Text, None]) -> NLUEvaluation:
    intent_report = {}
    intent_errors = {}
    if path_to_evaluation_result and Path(path_to_evaluation_result).is_dir():
        path_to_intent_report = Path(path_to_evaluation_result) / "intent_report.json"
        if path_to_intent_report.exists():
            intent_report = rasax.community.utils.io.read_json_file(
                path_to_intent_report
            )

        path_to_intent_errors = Path(path_to_evaluation_result) / "intent_errors.json"
        if path_to_intent_errors.exists():
            intent_errors = rasax.community.utils.io.read_json_file(
                path_to_intent_errors
            )
    else:
        rasa.shared.utils.cli.print_warning(
            "No test results found. Analyzes based on the test results will be "
            "skipped. Consider providing test results for more meaningful "
            "results using the '--test-results' flag. You can obtain the test results "
            "by running 'rasa test'."
        )

    return NLUEvaluation(intent_report, intent_errors)


def _config_from_file(
    linter_config_file: Optional[Union[Text, Path]]
) -> Optional[Dict[Text, Any]]:
    if not linter_config_file:
        return None

    linter_config_file = Path(linter_config_file)
    if not linter_config_file.is_file():
        return None

    try:
        return rasa.shared.utils.io.read_yaml_file(linter_config_file)
    except YamlSyntaxException as e:
        logger.error(
            f"Error when loading linter config from file '{linter_config_file}': {e}"
        )

    return None


def _get_default_database_url() -> Optional[Text]:
    local_rasa_x_db = Path("..") / "rasa.db"
    if local_rasa_x_db.exists():
        logger.debug("Found local Rasa X database.")
        return "sqlite:///rasa.db"

    if os.getenv(ENV_DB_URL) or os.getenv("DB_PASSWORD"):
        return str(rasax.community.database.utils.get_db_url(is_local=False))

    return None


def print_insights(insights: Dict[Text, List[Insight]]) -> None:
    """Prints the insight for the command-line tool.

    Args:
        insights: A mapping of insight per intent.
    """
    insights = OrderedDict(
        sorted(insights.items(), key=lambda item: len(item[1]), reverse=True)
    )

    table_data = [["Intent Name", "Warnings"]]
    for intent_name, suggestions in insights.items():
        if len(suggestions) >= 3:
            intent_name = rasa.shared.utils.io.wrap_with_color(
                intent_name, color=rasa.shared.utils.io.bcolors.WARNING
            )
        table_data.append(
            [
                intent_name,
                "\n\n".join(
                    [f"- {_column(str(suggestion))}" for suggestion in suggestions]
                ),
            ]
        )

    table = AsciiTable(table_data)
    table.inner_row_border = True

    print(table.table)


def _column(text: Text) -> Text:
    return "\n".join(textwrap.wrap(text, 140))


if __name__ == "__main__":
    default_database_url = _get_default_database_url()

    # noinspection PyTypeChecker
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description="NLU annotation helper. Analyzes training data, test results and "
        "Rasa X NLU inbox and gives suggestions based on these evaluations.",
    )
    parser.add_argument(
        "--linter-config",
        type=str,
        help="Optional configuration for the different checks which are performed.",
        default=None,
    )

    parser.add_argument(
        "--test-results",
        type=str,
        help="Path to the tests results for the model.",
        default=str(Path("results")),
    )

    parser.add_argument(
        "--database-url",
        type=str,
        help="URL of the Rasa X database",
        default=default_database_url,
    )

    parser.add_argument("--debug", action="store_true", help="Log Level", default=False)

    args = parser.parse_args()
    calculate_insights_for_cli(args)
