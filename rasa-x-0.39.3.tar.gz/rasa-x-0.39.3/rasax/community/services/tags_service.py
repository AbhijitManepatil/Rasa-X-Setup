from multiprocessing import context
from typing import Dict, Text, Any, cast, Optional, List

from rasax.community.database.conversation import DataTag
from rasax.community.database.service import DbService
import rasax.community.utils.common as common_utils
from sanic.request import Request

# Lock that is used to ensure tags are not inserted concurrently
from sqlalchemy.orm import Session

_tags_global_operation_lock = None


def initialize_global_state(mp_context: context.BaseContext) -> None:
    """Initialize module-level tags operation lock.

    This method has to be called first before any attempt to use TagsService.
    """
    global _tags_global_operation_lock
    _tags_global_operation_lock = mp_context.Lock()


class TagsService(DbService):
    """Service to deal with data tags."""

    def __init__(self, session: Session,) -> None:
        """Creates a `TagsService` instance.

        Args:
            session: The database session.
        """
        if not _tags_global_operation_lock:
            common_utils.logger.error(
                "Failed to initialize TagsService. The lock object has to be "
                "initialized before any attempt to use TagsService."
            )
            raise ValueError(
                "Failed to initialize TagsService as the concurrency lock "
                "wasn't initialized yet."
            )
        super().__init__(session)

    @staticmethod
    def from_request(request: Request, **kwargs) -> "TagsService":
        """Constructs `TagsService` from the HTTP request.

        Args:
            request: incoming HTTP request.
            **kwargs: other key-value args.

        Returns:
            `TagService` object.
        """
        return TagsService(request.ctx.db_session)

    def process_tag(self, tag: Dict[Text, Any]) -> DataTag:
        """Constructs a `DataTag` object from the given dictionary.

        Takes in JSON input from user that has data tags inside and further decides
        if it's "assign existing data tag id", or "assign and possibly create data
        tag by value".

        Args:
            tag: Raw JSON input from user.

        Returns:
            List of data tags with information about conversations and messages
            they're assigned to.
        """
        with _tags_global_operation_lock:
            tag_id = tag.get("id")

            if tag_id:
                existing_tag = self.get_tag_by_id(tag_id)
                if existing_tag is None:
                    raise ValueError(f"Tag {tag_id} does not exist.")
            elif "value" in tag and "color" in tag:
                existing_tag = self._get_tag_by_value(tag["value"])
                if existing_tag is None:
                    existing_tag = self._insert_tag(tag["value"], tag["color"])
                tag_id = existing_tag.id

            if not tag_id:
                raise ValueError(
                    f'Both "value" and "color" fields are expected in element: {tag}'
                )

            return cast(DataTag, existing_tag)

    def get_tag_by_id(self, tag_id: int) -> Optional[DataTag]:
        """Returns data with a given ID.

        Args:
            tag_id: ID of the tag.

        Returns:
            Data tag with a given ID.
        """
        return self.query(DataTag).filter(DataTag.id == tag_id).first()

    def delete_data_tag_by_id(self, tag_id: int) -> None:
        """Delete data tag with the given <tag_id>.

        Args:
            tag_id: ID of the the data tag to be deleted.
        """
        tag = TagsService(self.session).get_tag_by_id(tag_id)
        if not tag:
            raise ValueError(f"Tag with id '{tag_id}' was not found.")

        self.delete(tag)
        self.commit()

    def get_all_data_tags(self) -> List[Dict[Text, Any]]:
        """Returns all existing data tags.

        Returns:
            List of existing data tags.
        """
        tags = self.query(DataTag).all()
        return [t.as_dict() for t in tags]

    def _get_tag_by_value(self, tag_value: Text) -> Optional[DataTag]:
        return self.query(DataTag).filter(DataTag.value == tag_value).first()

    def _insert_tag(self, tag_value: Text, color: Text) -> DataTag:
        new_tag = DataTag(value=tag_value, color=color)
        self.add(new_tag)
        self.commit()

        return new_tag
