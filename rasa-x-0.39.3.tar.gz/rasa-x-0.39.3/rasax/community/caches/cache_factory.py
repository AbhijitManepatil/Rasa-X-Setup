import logging
from typing import Any, Dict, Optional, Text

from rasax.community.caches.cache import Cache
from rasax.community.caches.redis_cache import RedisCache
from rasax.community.caches.stub_cache import StubCache

logger = logging.getLogger(__name__)


class CacheFactory:
    """Factory class that is used to construct different types of cache."""

    @staticmethod
    def from_endpoint_config(
        config: Optional[Dict[Text, Any]], component_prefix: Text
    ) -> Cache:
        """Constructs a cache from the endpoints configuration file.

        Args:
            config: Rasa X endpoints configuration.
            component_prefix: prefix to prepend to all keys used by the cache.
                Must be alphanumeric.

        Returns:
            Constucted Cache object.
        """
        if not config or not isinstance(config, dict):
            return StubCache()

        if config.get("type", "") == "redis":
            return RedisCache(
                config.get("url", "localhost"),
                config.get("port", 6379),
                config.get("db", 2),
                config.get("password"),
                config.get("use_ssl", False),
                config.get("key_prefix"),
                component_prefix,
            )

        return StubCache()
