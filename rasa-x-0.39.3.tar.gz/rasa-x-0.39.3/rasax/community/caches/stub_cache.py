from typing import Any, Optional, Text

from rasax.community.caches.cache import Cache


class StubCache(Cache):
    """Stub implementation of the Cache that always misses."""

    def get(self, key: Text) -> Optional[Any]:
        """Stub implementation of `get` that always returns `None`.

        Args:
            key: value of the key.

        Returns:
            `None`, as this a stub cache.
        """
        return None

    def set(self, key: Text, value: Text, expire_time: Optional[int] = None) -> None:
        """Stub implementation of `set` that doesn't set anything.

        Args:
            key: value of the key.
            value: value that will be set at `key`.
            expire_time: expire time of the `key`, in seconds.
        """
        pass
