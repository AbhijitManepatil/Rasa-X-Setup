import logging
from http import HTTPStatus
from typing import Text

from rasax.community.api.decorators import rasa_x_scoped, validate_schema
from rasax.community import telemetry
from rasax.community.services.event_service import EventService
from rasax.community.services.logs_service import LogsService
from rasax.community.services.tags_service import TagsService
from sanic import Blueprint, response
from sanic.request import Request
from sanic.response import HTTPResponse

import rasax.community.utils.cli as cli_utils
import rasax.community.utils.common as common_utils

logger = logging.getLogger(__name__)


def blueprint() -> Blueprint:
    """Endpoints related to data tags.

    Returns:
        `Sanic Blueprint` with the endpoints.
    """
    tags_endpoints = Blueprint("data_tags_endpoints")

    @tags_endpoints.route(
        "/conversations/<conversation_id:string>/tags", methods=["POST"]
    )
    @validate_schema("data_tags")
    async def add_tags_to_conversation(
        request: Request, conversation_id: Text
    ) -> HTTPResponse:
        """Assigns tags to <conversation_id>. If tags don't exist, they will be created.

        Args:
            request: Incoming HTTP request.
            conversation_id: Id of conversation to assign tags to.

        Returns:
            List of assigned tags in format of JSON schema `data_tags`.
        """
        try:
            tags = EventService.from_request(request).add_tags_to_conversation(
                conversation_id, request.json
            )

            telemetry.track_conversation_tagged(len(tags))

            return response.json(tags, headers={"X-Total-Count": len(tags)})
        except ValueError as e:
            return common_utils.error(
                HTTPStatus.NOT_FOUND, "Failed to add tags to conversation", str(e)
            )

    @tags_endpoints.route(
        "/conversations/<conversation_id:string>/tags/<tag_id:int>", methods=["DELETE"]
    )
    @rasa_x_scoped("conversationDataTag.delete")
    async def delete_tag_from_conversation(
        request: Request, conversation_id: Text, tag_id: int
    ) -> HTTPResponse:
        """Removes tag with <tag_id> from <conversation_id>.

        Args:
            request: Incoming HTTP request.
            conversation_id: Id of conversation to remove tag from.
            tag_id: Id of a tag that will be removed.
        """
        try:
            EventService.from_request(request).remove_tag_from_conversation(
                conversation_id, tag_id
            )

            return response.json("", status=HTTPStatus.NO_CONTENT)
        except ValueError as e:
            return common_utils.error(
                HTTPStatus.NOT_FOUND, "Failed to delete tag from conversation", str(e)
            )

    @tags_endpoints.route("/conversations/tags", methods=["GET", "HEAD"])
    @rasa_x_scoped("conversationDataTag.list")
    async def get_all_conversation_tags(request: Request) -> HTTPResponse:
        """Returns all existing data tags.

        Data tags also specify which items they're assigned to.

        Args:
            request: Incoming HTTP request.

        Returns:
            List of existing tags.
        """
        cli_utils.raise_warning(
            'The "GET /conversations/tags" endpoint is deprecated. '
            'Please use "GET /data_tags" instead".',
            category=FutureWarning,
        )
        tags = TagsService.from_request(request).get_all_data_tags()
        return response.json(tags, status=HTTPStatus.OK)

    @tags_endpoints.route("/data_tags", methods=["GET", "HEAD"])
    @rasa_x_scoped("dataTags.list")
    async def get_all_data_tags(request: Request) -> HTTPResponse:
        """Returns all existing data tags.

        Data tags also specify which items they're assigned to.

        Args:
            request: Incoming HTTP request.

        Returns:
            List of existing tags.
        """
        tags = TagsService.from_request(request).get_all_data_tags()
        return response.json(tags, status=HTTPStatus.OK)

    @tags_endpoints.route(
        "/conversations/<conversation_id:string>/tags", methods=["GET", "HEAD"]
    )
    @rasa_x_scoped("conversationDataTag.list")
    async def get_tags_for_conversation_id(
        request: Request, conversation_id: Text
    ) -> HTTPResponse:
        """Returns all existing data tags for a given <conversation_id>.

        Args:
            request: Incoming HTTP request.

        Returns:
            List of existing tags.
        """
        try:
            tags = EventService.from_request(request).get_tags_for_conversation_id(
                conversation_id
            )
            return response.json(tags, status=HTTPStatus.OK)
        except ValueError as e:
            return common_utils.error(
                HTTPStatus.NOT_FOUND,
                f"Failed to get tags. Conversation '{conversation_id}' was not found",
                str(e),
            )

    @tags_endpoints.route("/conversations/tags/<tag_id:int>", methods=["DELETE"])
    @rasa_x_scoped("conversationDataTag.delete")
    async def delete_conversation_tag_by_id(
        request: Request, tag_id: int
    ) -> HTTPResponse:
        """Deletes data tag with the given <tag_id>.

        Args:
            request: Incoming HTTP request.
            tag_id: ID of the tag to be deleted.
        """
        cli_utils.raise_warning(
            'The "DELETE /conversations/tags" endpoint is deprecated. '
            'Please use "DELETE /data_tags/<data_tag_id>" instead".',
            category=FutureWarning,
        )
        try:
            TagsService.from_request(request).delete_data_tag_by_id(tag_id)

            return response.json("", status=HTTPStatus.NO_CONTENT)
        except ValueError as e:
            return common_utils.error(
                HTTPStatus.NOT_FOUND,
                f"Failed to delete tag: tag with id '{tag_id}' was not found",
                str(e),
            )

    @tags_endpoints.route("/data_tags/<data_tag_id:int>", methods=["DELETE"])
    @rasa_x_scoped("logDataTag.delete")
    async def delete_data_tag_by_id(request: Request, data_tag_id: int) -> HTTPResponse:
        """Deletes data tag with the given <tag_id>.

        Args:
            request: Incoming HTTP request.
            data_tag_id: ID of the tag to be deleted.
        """
        try:
            TagsService.from_request(request).delete_data_tag_by_id(data_tag_id)

            return response.json("", status=HTTPStatus.NO_CONTENT)
        except ValueError as e:
            return common_utils.error(
                HTTPStatus.NOT_FOUND,
                f"Failed to delete tag: tag with id '{data_tag_id}' was not found",
                str(e),
            )

    @tags_endpoints.route(
        "/projects/<project_id>/logs/<log_id:int>/tags", methods=["POST"]
    )
    @validate_schema("data_tags")
    @rasa_x_scoped("logDataTag.create")
    async def add_tags_to_message(
        request: Request, project_id: Text, log_id: int
    ) -> HTTPResponse:
        """Assigns tags to message <log_id>. If tags don't exist, they will be created.

        Args:
            request: Incoming HTTP request.
            project_id: Project id of the message.
            log_id: Id of message to assign tags to.

        Returns:
            List of assigned tags.
        """
        try:
            tags = LogsService.from_request(request).add_tags_to_message(
                log_id, request.json
            )

            telemetry.track_message_tagged(len(tags))

            return response.json(tags, headers={"X-Total-Count": len(tags)})
        except ValueError as e:
            return common_utils.error(
                HTTPStatus.NOT_FOUND, "Failed to add tags to message", str(e)
            )

    @tags_endpoints.route(
        "/projects/<project_id>/logs/<log_id:int>/tags/<tag_id:int>", methods=["DELETE"]
    )
    @rasa_x_scoped("logDataTag.delete")
    async def delete_tag_from_message(
        request: Request, project_id: Text, log_id: int, tag_id: int
    ) -> HTTPResponse:
        """Removes tag with <tag_id> from message <log_id>.

        Args:
            request: Incoming HTTP request.
            project_id: Project id of the message.
            log_id: Id of message to remove tag from.
            tag_id: Id of a tag that will be removed.
        """
        try:
            LogsService.from_request(request).remove_tag_from_message(log_id, tag_id)

            return response.json("", status=HTTPStatus.NO_CONTENT)
        except ValueError as e:
            return common_utils.error(
                HTTPStatus.NOT_FOUND, "Failed to delete tag from message", str(e)
            )

    return tags_endpoints
