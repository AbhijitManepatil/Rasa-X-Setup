from typing import Text, List, Tuple, Set, Optional
from pathlib import Path
from enum import Enum, unique


@unique
class FileFormat(Enum):
    MARKDOWN = ".md"
    YAML = ".yml"
    JSON = ".json"
    GRAPHVIZ = ".dot"


_CONTENT_TYPES: List[Tuple[Set[Text], Set[Text], FileFormat]] = [
    # Tuples of:
    # - File extensions set
    # - MIME-type set
    # - Enum value
    ({".md"}, {"text/markdown", "text/x-markdown"}, FileFormat.MARKDOWN),
    (
        {".yml", ".yaml"},
        {"text/yaml", "text/x-yaml", "application/yaml", "application/x-yaml",},
        FileFormat.YAML,
    ),
    ({".json"}, {"application/json"}, FileFormat.JSON),
    ({".dot", ".gv"}, {"text/vnd.graphviz"}, FileFormat.GRAPHVIZ),
]


def format_from_mime_type(
    mime_type: Text, default: Optional[FileFormat] = None
) -> FileFormat:
    """Returns a `FileFormat` given a MIME type. Note that `mime_type` can
    contain a list of comma-separated types.

    Arguments:
        mime_type: MIME type as text.
        default: Default `FileFormat` to return if no matching type was found.

    Raises:
        ValueError: If MIME type could not be recognized.

    Returns:
        `FileFormat` corresponding to the MIME type.
    """
    types_list = [ct.strip() for ct in mime_type.split(",")]

    for type_entry in types_list:
        for _, content_types, file_format in _CONTENT_TYPES:
            if type_entry in content_types:
                return file_format

    if default:
        return default

    raise ValueError(f"No matches for MIME type '{mime_type}'.")


def format_from_filename(filename: Text) -> FileFormat:
    """Returns a `FileFormat` given a file path.

    Arguments:
        filename: String containing a file path.

    Raises:
        ValueError: If the file's format could not be determined.

    Returns:
        `FileFormat` corresponding to the file path.
    """
    suffix = Path(filename).suffix

    for extensions, _, file_format in _CONTENT_TYPES:
        if suffix in extensions:
            return file_format

    raise ValueError(f"Unknown file format for: '{filename}'.")


def extensions_from_format(fileformat: FileFormat) -> Set[Text]:
    """Returns a `Set[Text]` given a FileFormat.

    Arguments:
        fileformat: File format.

    Raises:
        ValueError: If the file_format's extension(s) could not be determined.

    Returns:
        `Set[Text]` corresponding to the extension(s).
    """
    for file_extension, _, file_format in _CONTENT_TYPES:
        if fileformat == file_format:
            return file_extension

    raise ValueError(f"No matches for FileFormat '{fileformat}'.")


def mime_type_from_format(fileformat: FileFormat) -> Set[Text]:
    """Returns MIME types for a given `FileFormat`.

    Arguments:
        fileformat: File format.

    Raises:
        ValueError: If the MIME types could not be determined.

    Returns:
        `Set[Text]` corresponding to the MIME types.
    """
    for _, mime_type, file_format in _CONTENT_TYPES:
        if fileformat == file_format:
            return mime_type

    raise ValueError(f"No matches for FileFormat '{fileformat}'.")


def best_format_for_content(filenames: Set[Text]) -> Text:
    """Returns a list of preferred MIME types for a given set of filenames.

    Arguments:
        filenames: `Set[Text]`.

    Returns:
        `Text` corresponding to a string of comma separated MIME types.
    """
    file_extensions = {Path(filename).suffix for filename in filenames if filename}

    yml_extensions = extensions_from_format(FileFormat.YAML)
    is_yaml = yml_extensions.intersection(file_extensions)

    if is_yaml:
        mime_type = mime_type_from_format(FileFormat.YAML)
    else:
        md_extension = extensions_from_format(FileFormat.MARKDOWN)
        is_md = md_extension.intersection(file_extensions)

        if is_md:
            mime_type = mime_type_from_format(FileFormat.MARKDOWN)
        else:
            mime_type = mime_type_from_format(FileFormat.JSON)

    return ",".join(sorted(mime_type))
